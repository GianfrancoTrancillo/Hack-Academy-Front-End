$("#btn-show-hide").on(("click"), function (){
    if ($("p").css("display") === "none") {
        $("p").slideDown();
    } else {
        $("p").fadeOut();
    }

});



// ejercicio3:

function formatP() {
    $("p").addClass("verde");
};