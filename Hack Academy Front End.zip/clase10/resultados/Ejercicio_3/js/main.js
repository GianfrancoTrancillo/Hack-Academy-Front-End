/*****************************************************************************/

// Ejercicio 3 - Parte A:
// Notar que esta función no lleva argumentos ni `return`.
// Es necesario tener jQuery instalado para que funcione.

function formatP() {
  $("p").css("color", "#4CAF50");
  $("p").css("font-size", "12px");
}

/*****************************************************************************/

// Ejercicio 3 - Parte B:
// Notar que esta función no lleva argumentos ni `return`.
// Es necesario tener jQuery instalado para que funcione.

function lorem() {
  $("p").text(
    "Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
  );
}

/*****************************************************************************/

// Ejercicio 3 - Parte C:
// Notar que esta función no lleva `return`.
// Parámetros:
//     * texto: el texto que se debe repetir.
// 	   * repeticiones: la cantidad de veces que se debe repetir.

function alertRepetido(texto, repeticiones) {
  var textoAMostrar = ""; // Variable auxiliar, inicializada con string vacío.

  for (var i = 1; i <= repeticiones; i++) {
    textoAMostrar = textoAMostrar + texto + " ";
  }

  alert(textoAMostrar);
}

// Para testear que funcione probar con:
// alertRepetido("Hola", 3); // Se debería mostrar un alert con el texto "Hola Hola Hola".
// alertRepetido("UY", 5); // Se debería mostrar un alert con el texto "UY UY UY UY UY".

/*****************************************************************************/

/**
 * // Ejercicio 3 - Parte D:
 *
 * Este es un ejercicio AVANZADO y no es tan importante para el curso.
 *
 * Notar que esta función no lleva argumentos ni `return`.
 * Es necesario tener jQuery instalado para que funcione.
 */

function alarma() {
  // Varaible auxiliar que contiene el color del fondo.
  // Inicualmente es blanco.
  var color = "blanco";

  // Función auxiliar para cambiar el color del fondo.
  // Notar que esta función se definió dentro de la función alarma.
  var cambiarColorDeFondo = function () {
    if (color === "blanco") {
      $("body").css("background-color", "#D32F2F");
      color = "rojo";
    } else {
      $("body").css("background-color", "#FFFFFF");
      color = "blanco";
    }
  };

  // A continuación se usan las funciones `setInterval`, `setTimeout` y `clearInterval`.
  // Conviene leer la documentación de cada una.

  // `setInterval` ejecuta cierta función en intervalos de tiempos predefinidos.
  // En este caso, se llama a `cambiarColorDeFondo` cada 150 milisegundos.
  var tics = setInterval(function () {
    cambiarColorDeFondo();
  }, 150);

  // `setTimeout` ejecuta cierta función luego de transcurrido cierto tiempo.
  // En este caso, se espera 5000 milisegundos y luego se ejecuta `clearInterval`.
  // Al llamar a `clearInterval(tics)` se deja de ejecutar el intervalo llamado `tics`.
  var stop = setTimeout(function () {
    clearInterval(tics);
    $("body").css("background-color", "#FFFFFF"); // Para que finalice con fondo blanco.
  }, 5000);
} // Fin - Alarma
