$("#btn-show-hide").on("click", function () {

    var parr = $("#p1");                // Variable que contine el elemento #p1.
    var disp = parr.css("display");     // Variable que contiene el valor de la propiedad display.

    /*
     * A continuación se consulta si el párrafo está oculto, es decir, si la
     * propiedad display del mismo vale "none".
     * En caso afirmativo, se oculta el párrafo. En caso contrario, se muestra.
     *
     * En este ejemplo se usó el efecto "slide" para mostrar el párrafo
     * y el efecto "fade" para ocultarlo.
     *
     */
    if (disp === "none") {
        parr.slideDown();
    } else {
        parr.fadeOut();
    }

});


/*
 * NOTAS:
 *
 * El uso de las varialbes parr y disp es totalmente opcional.
 * De hecho, en este ejemplo no aportan mucho.
 * Pero podrían ser útiles si se volviesen a usar más adelante en el código.
 *
 * Otro motivo por el cual puede ser útil usar dichas variales, es para hacer
 * más claro el código. Por ejemplo, ver el IF de esta manera:
 *
 * 		if (disp === "none") { ... }
 *
 * puede ser más claro que verlo así:
 *
 *		if ($("#p1").css("display") === "none") { ... }
 *
 *
 *
 * Otra opción que se podría haber hecho para este ejercicio es usar la opción Toggle.
 * Por ejemplo, slideToggle o fadeToggle. De esta forma no sería necesario el IF/ELSE.
 * La desventaja de usar el Toggle es que se debe usar el mismo efecto para hacer
 * aparecer el párrafo como para ocultarlo.
 *
 */
