// VERSIÓN 1:
// Se usan unas clases bg-1 y bg-2 que contendrán los estilos de cada background.
// Importante: Esta versión sólo funciona en caso de que no se hayan presionado
// los botones de las otras versiones.

$("#btn-1").on("click", function () {
  var body = $("body");

  if (body.hasClass("bg-1")) {
    body.removeClass("bg-1");
    body.addClass("bg-2");
  } else {
    body.removeClass("bg-2");
    body.addClass("bg-1");
  }
});

/****************************************************************************/

// VERSIÓN 2:

// Variable auxiliar para saber guardar el color de fondo actual.
// Inicialmente es rojo:
var colorActual = "rojo";

$("#btn-2").on("click", function () {
  if (colorActual === "rojo") {
    // Se cambia color a verde:
    $("body").css("background-color", "#66BB6A");
    colorActual = "verde";
  } else {
    // Se cambia color a rojo:
    $("body").css("background-color", "#EF5350");
    colorActual = "rojo";
  }
});

// También se podría haber hecho algo similar pero con una variable
// booleana llamada "colorActualEsRojo".

/****************************************************************************/

// VERSIÓN 3:

$("#btn-3").on("click", function () {
  var color = $("body").css("background-color"); // Retorna color en formato RGB.

  if (color === "rgb(239, 83, 80)") {
    // Se cambia color a verde:
    $("body").css("background-color", "#66BB6A");
  } else {
    // Se cambia color a rojo:
    $("body").css("background-color", "#EF5350");
  }
});

/****************************************************************************/

// VERSIÓN 4:
// Esta es la versión más corta de todas.
// Se utilizó la funcionalidad "toggleClass" de jQuery.
// Importante: Esta versión sólo funciona en caso de que no se hayan presionado
// los botones de las otras versiones.

$("#btn-4").on("click", function () {
  $("body").toggleClass("bg-1");
});
