function formatP() {
    $("p").css("color", "green")
    $("p").css("font-size", "12px")
};

function lorem() {
    $("p").text("lorem .......");
    
};

function alertRepetido(n,s) {
    alertRepetido("que onda amigo", 4)
    
}