var fondoEsVerde = true;
$("#btn-cambiar").on("click", function () {
  if (fondoEsVerde) {
    $("body").css("background-color", "red");
    fondoEsVerde = false;
  } else {
    $("body").css("background-color", "green");
    fondoEsVerde = true;
  }
});



$("#btn-cambiar").on("click", function() {
if ($("body").css("background-color", "green") {
  $("body").css("background-color", "red"); 
} else {
  $("body").css("background-color", "green");
  
}


});