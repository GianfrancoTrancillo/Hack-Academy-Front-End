function validarAnioNacimiento(num) {
  if (typeof num == "number" && num > 1920 && num <= 2020) {
    return true;
  } else {
    return false;
  }
}
function maximoDeDos(num1, num2) {
  if (num1 >= num2) {
    return num1;
  }
  if (num2 > num1) {
    return num2;
  }
}
