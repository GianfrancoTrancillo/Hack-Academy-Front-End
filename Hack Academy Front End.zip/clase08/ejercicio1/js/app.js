function duplicar(numA) {
  return numA * 2;
}
duplicar(4.5);
