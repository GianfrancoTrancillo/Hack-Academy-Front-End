function mostrarNombre(nombre, apellido) {
  alert("Tu nombre es " + nombre + " y tu apellido " + apellido);
}
