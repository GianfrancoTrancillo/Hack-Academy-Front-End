function duplicar(numero) {
  return numero * 2;
}

/*****************************************************************************/

// Tests:
console.log("Ejercicio 1");
console.log(duplicar(0)); // Debería retonar 0.
console.log(duplicar(1)); // Debería retonar 1.
console.log(duplicar(3)); // Debería retonar 6.
console.log(duplicar(-3)); // Debería retonar -6.
