function numeroAleatorio() {
  var numAleatorio = Math.random() * 100;
  return Math.round(numAleatorio);
}

/*****************************************************************************/

// Tests:
console.log("\nEjercicio 3");
console.log(numeroAleatorio());
console.log(numeroAleatorio());
console.log(numeroAleatorio());
