function mostrarNombre(nombre, apellido) {
  alert("Tu nombre es " + nombre + " y tu apellido es " + apellido);
}

/*****************************************************************************/

// Test:
mostrarNombre("María", "Pérez");
