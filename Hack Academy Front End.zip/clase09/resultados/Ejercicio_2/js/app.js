function toggleMenu() {
  // La siguiente línea de código "selecciona" el elemento de la página
  // que contenga la clase ".dropdown-menu".
  var menu = document.querySelector(".dropdown-menu");

  // Luego se consulta si dicho elemento tiene la propiedad "display"
  // seteada en "block". En caso afirmativo, se setea en "none".
  // En caso negativo, se setea en "block".
  if (menu.style.display === "block") {
    menu.style.display = "none";
  } else {
    menu.style.display = "block";
  }
}
