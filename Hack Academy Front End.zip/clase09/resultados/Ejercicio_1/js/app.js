function buscarTitulo() {
  // La siguiente línea de código "selecciona" el elemento <h1> de la página.
  // Si el elemento no se encuentra, el resultado de la "selección" es null.
  var titulo = document.querySelector("h1");

  // Luego de seleccionar el elemento, se valida si es null o no:
  if (titulo == null) {
    alert("ERROR: Falta título");
  } else {
    titulo.style.fontFamily = "Times New Roman";
  }
}

// Llamada a la función:
buscarTitulo();

// Probarlo también en https://ha.edu.uy y en https://ha.edu.uy/home-no-h1.
