function buscarTitulo() {
  if (document.querySelector("h1") == null) {
    alert("Error: falta titulo.");
  } else {
    document.querySelector("h1").style.fontFamily = "Times New Roman";
  }
}

function toggleMenu() {
  if (document.querySelector(".dropdown-menu").style.display === "none") {
    document.querySelector(".dropdown-menu").style.display = "block";
  } else {

    document.querySelector(".dropdown-menu").style.display = "none"
  }
}
