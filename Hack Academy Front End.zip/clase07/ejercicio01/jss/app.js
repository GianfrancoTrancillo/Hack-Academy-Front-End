var sumando1 = (154 * 56) / 98;
var sumando2 = (867 - 56) / 13;
var result = sumando1 + sumando2 + 43;
alert("El resultado es: " + result);
