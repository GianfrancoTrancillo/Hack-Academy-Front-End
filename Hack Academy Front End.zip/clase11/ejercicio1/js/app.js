$(".alert").hide();

$("button").on("click", function () {
  var varTitulo = $("#titulo").val();
  $("h1").text(varTitulo);
  var fontSize = $("#tit-size").val();
  $("h1").css("font-size", fontSize + "px");

  var varParrafo = $("#parrafo").val();
  $("p").text(varParrafo);

  var colorTitulo = $("input[name=color]:checked").val();
  $("h1").css("color", colorTitulo);

  if (varTitulo == "" || varParrafo == "") {
    $(".alert-danger").show();
  } else {
    $(".alert-success").show();
  }
});
