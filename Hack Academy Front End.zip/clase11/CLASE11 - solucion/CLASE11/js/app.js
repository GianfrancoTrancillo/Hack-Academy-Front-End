$(".alert").hide();

$("button").on("click", function () {
  $(".alert").hide();
  var varTitulo = $("#titulo").val();
  $("h1").text(varTitulo);

  var fontSize = $("#titSize").val();
  $("h1").css("font-size", fontSize + "px");

  var varParrafo = $("#parrafo").val();
  $("p").text(varParrafo);

  var colorTitulo = $("input[name=color]:checked").val();
  $("h1").css("color", colorTitulo);

  // Aqui tenemos que comprar el cartel
  if (varTitulo == "" || varParrafo == "") {
    $(".alert-danger").show();
  } else {
    $(".alert-success").show();
  }
});
