// Mi código JavaScript:

var appSales = new Vue({
  el: "#sales",
  data: {
    cotizacion: "",
    cars: [],
    years: [],
    brands: [],
    models: [],

    yearSelected: "",
    brandSelected: "",
    modelSelected: "",
    statusSelected: "",
    currentCurrency: "usd"
  },
  filters: {
      upperCase: function (value) {
          return value.toUpperCase()
      },
      formatNumber: function (value) {
        return parseInt(value).toLocaleString("es-UY");
      },
  },
});

var today = new Date();
for (var i = today.getFullYear(); i >= 1980; i--) {
  appSales.years.push(i);
}

$.ajax({
  url: "https://ha.edu.uy/api/rates",
  success: function (data) {
    appSales.cotizacion = data.uyu;
  },
});

$.ajax({
  url: "https://ha.edu.uy/api/brands",
  success: function (brands) {
    appSales.brands = brands;
  },
});

$("#brand").change(function () {
  $.ajax({
    url: "https://ha.edu.uy/api/models?brand=" + appSales.brandSelected,
    success: function (models) {
      appSales.models = models;
    },
  });
});

//Autos

$.ajax({
    url: "https://ha.edu.uy/api/cars",
    success: function (cars) {
      appSales.cars = cars;
    },
  });


  $("#btn-currency").click(function () {
    if (appSales.currentCurrency == "usd") {
        appSales.currentCurrency = "uyu"
    } else {
        appSales.currentCurrency = "usd"
    }
  });

  $("#btn-filtrar").click(function () {
    console.log("funciono");
    $.ajax({
      url: "https://ha.edu.uy/api/cars?year=" + appSales.yearSelected + "&brand=" + appSales.brandSelected + "&model=" + appSales.modelSelected + "&status=" + appSales.statusSelected,
      success: function (cars) {
        appSales.cars = cars;
      },
    });
  });

