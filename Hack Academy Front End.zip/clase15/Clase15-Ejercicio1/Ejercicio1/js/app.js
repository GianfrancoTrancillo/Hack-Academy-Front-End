/* id, title, content, author, url, image */

var blogHA = new Vue ({
    el: "#posts",
    data: {
       posts: postList,
    }
});