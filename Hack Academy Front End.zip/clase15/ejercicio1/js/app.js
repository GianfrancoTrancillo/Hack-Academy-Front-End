var blogHA = new Vue({
    el: "#posts",
    data: {
        posts: postList,
    }
});