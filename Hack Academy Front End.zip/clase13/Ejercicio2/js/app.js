$().keydown(function(e){
   e.preventDefault();
   var move = $("#container").addClass("")
   if (e.keyCode === 37) {
       
   } else {
       
   }
})