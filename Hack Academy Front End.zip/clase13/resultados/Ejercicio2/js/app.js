/******************************************************************************

     CLASE 13 - Ejercicio 2

******************************************************************************/

/**
 * Nota:
 * Esta solución, si bien funciona, puede ser mejorada.
 * Por ejemplo, esta solución no funciona si se modifica el tamaño del
 * elemento "#container" (que en este caso es de 600x400 pixeles).
 */

$(document).on("keydown", function(e) {

    // Es necesario prevenir (evitar) la acción por default de las flechas.
    // Es decir, evitar que al teclear las flechas se haga scroll de la página.
    // Esto se logra con preventDefault:
    e.preventDefault();


    var valorTop 	= $("#box").css("top");
    var valorLeft 	= $("#box").css("left");

    console.log("Se apretó la tecla número: " + e.keyCode);

    if (e.keyCode === 37) {
        // LEFT
        valorLeft = "0px";
    } else if (e.keyCode === 38) {
        // UP
        valorTop = "0px";
    } else if (e.keyCode === 39) {
        // RIGHT
        valorLeft = "500px";
    } else if (e.keyCode === 40) {
        // DOWN
        valorTop = "300px";
    }

    /*
        NOTA:
        En este caso, en lugar de haber usado 4 IF's, se podría haber usado otra
        estructura de control llamada SWITCH.
        Más info aquí: https://www.w3schools.com/js/js_switch.asp.
        El resultado es el mismo y a veces queda más prolijo.
        Quedaría algo así:

            switch (e.which) {
                case 37:
                    left = "0px";
                    break;

                case 38: // UP
                    top = "0px";
                    break;

                case 39: // RIGHT
                    left = "500px";
                    break;

                case 40: // DOWN
                    top = "300px";
                    break;
            }

    */


    $("#box").css("top", valorTop);
    $("#box").css("left", valorLeft);

});


/**
 * Para lograr una solución que funcione para cualquier tamaño del container,
 * es necesario usar los valores "right" y "bottom" (además de "left" y "top").
 */
