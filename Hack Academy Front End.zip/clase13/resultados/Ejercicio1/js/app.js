/******************************************************************************

     CLASE 13 - Ejercicio 1

******************************************************************************/

/**
 * Función que valida si un email es válido.
 * Recibe un string y retorna true si corresponde a un email válido.
 * En caso contrario, retorna false.
 */

function validarEmail(email) {
    var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
    return re.test(String(email).toLowerCase());
}

/******************************************************************************/

/**
 * Función que obtiene el texto ingresado por el usuario.
 * Si se trata de un email válido, quita el color rojo del input.
 * En caso contrario, pone el color rojo en el input.
 */

function cambiarColorInput() {

    // Se selecciona el campo de texto (input):
    var input_email = $("#email"); 

    // Se verifica que se pueda acceder al texto ingresado:
    console.log("Texto ingresado: " + input_email.val());

    // Se valida que el texto ingresado tenga el formato
    // correspondiente a un correo electrónico: 
    if (validarEmail(input_email.val()) === true) {
        console.log("Email válido :)");
        input_email.addClass("valid");
        input_email.removeClass("not-valid");
    } else {
        console.log("Email no válido :(");
        input_email.addClass("not-valid");
        input_email.removeClass("valid");
    }
}

/******************************************************************************/

// Detección de Eventos:

$("#email").on("input", function() {
    console.log("Se detectó un cambio en el formulario.");
    cambiarColorInput();
});

$("#formulario").on("submit", function (event) {
    event.preventDefault();
    console.log("El ususario intentó hacer submit del formulario.");
    cambiarColorInput();
    // Luego, aquí se podrían proceder a enviar los datos del formulario a un servidor.
});
