function validarEmail(email) {
  var re = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
  return re.test(String(email).toLowerCase());
}

var email = $("#email");
email.keyup(function () {
  if (validarEmail(email.val()) == true) {
    email.addClass("valid")
    email.removeClass("not-valid")
  } else {
    email.addClass("not-valid")
    email.removeClass("valid");
  }
});
