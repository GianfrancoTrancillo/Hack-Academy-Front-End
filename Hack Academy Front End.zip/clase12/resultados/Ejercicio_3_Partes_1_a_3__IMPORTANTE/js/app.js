/******************************************************************************

     CLASE 12 - Ejercicio 3 - Partes 1 a 3

******************************************************************************/

// Arrays para probar:
var marcas = ["BMW", "Peugeot", "Chevrolet", "Subaru", "Nissan"];
var frutas = ["Manzana", "Naranja", "Banana", "Pera", "Ciruela", "Frutilla"];
var edades = [45, 10, 2, 89, 99, 23, 21, 90, 23, 3, 10, 7];

// Ejercicio 3 - Parte 1:

function mostrarArray(lista) {
  for (var i = 0; i < lista.length; i++) {
    console.log(lista[i]);
  }
}

/******************************************************************************/

// Ejercicio 3 - Parte 2:

function estaElemento(lista, elemento) {
  // Variable auxiliar para guardar si el elemento está (true) o no (false) en la lista.
  // Inicialmente se supone que no está.
  var esta = false;

  // Variable auxiliar para guardar la posición de la lista que se está recorriendo.
  // Se empieza por la posición 0.
  var posicion = 0;

  while (!esta && posicion < lista.length) {
    if (lista[posicion] == elemento) {
      esta = true;
    }
    posicion++;
  }

  return esta;
}

// Otra manera de resolver la Parte 2:

function estaElemento_v2(lista, elemento) {
  for (var i = 0; i < lista.length; i++) {
    if (lista[i] == elemento) {
      return true;
    }
  }
  return false;
}

// Otra manera de resolver la Parte 2:
// Usando la función `indexOf`, integrada en JavaScript.
// Link: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Array/indexOf

function estaElemento_v3(lista, elemento) {
  return lista.indexOf(elemento) != -1;
}

// Este ejercicio también se podría haber resuelto con la función `includes` de JavaScript,
// aunque no es compatible con ninguna versión de Internet Explorer.
// Link: https://developer.mozilla.org/es/docs/Web/JavaScript/Referencia/Objetos_globales/Array/includes

/******************************************************************************/

// Ejercicio 3 - Parte 3:

function maximo(lista) {
  // Inicialmente, suponemos que el máximo elemento es el primero:
  var max = lista[0];

  // Luego, recorremos la lista a partir del segundo elemento.
  // Por eso el for comienza en 1 (y no en cero).
  for (var i = 1; i < lista.length; i++) {
    if (max < lista[i]) {
      max = lista[i];
    }
  }

  // Finalmente, retornamos el máximo:
  return max;
}

/******************************************************************************/

// TESTS:

console.log("Las marcas que hay guardadas son:");
mostrarArray(marcas);

console.log(""); // Genera una línea vacía.

console.log("Las frutas que hay guardadas son:");
mostrarArray(frutas);

console.log(""); // Genera una línea vacía.

console.log("¿Peugeot está en el array de marcas?");
console.log(estaElemento(marcas, "Peugeot"));

console.log(""); // Genera una línea vacía.

console.log("¿Volvo está en el array de marcas?");
console.log(estaElemento(marcas, "Volvo"));

console.log(""); // Genera una línea vacía.

console.log("Limón está en el array de frutas?");
console.log(estaElemento(frutas, "Limón"));

console.log(""); // Genera una línea vacía.

console.log("¿Frutilla está en el array de frutas?");
console.log(estaElemento(frutas, "¿Frutilla"));

console.log(""); // Genera una línea vacía.

console.log("¿Cuál es la mayor edad del array de edades?");
console.log(maximo(edades));
