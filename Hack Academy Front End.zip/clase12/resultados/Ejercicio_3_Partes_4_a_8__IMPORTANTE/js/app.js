/******************************************************************************

     CLASE 12 - Ejercicio 3 - Partes 4 a 8

******************************************************************************/

var marcas = ["BMW", "Peugeot", "Chevrolet", "Subaru", "Nissan"];

// Ejercicio 3 - Parte 4
// Versión usando FOR y función `html` de jQuery

function mostrarMarcas_v1() {
  var htmlAux = ""; // Variable auxiliar que contendrá el listado de <li>.

  for (var pos = 0; pos < marcas.length; pos++) {
    htmlAux = htmlAux + "<li>" + marcas[pos] + "</li>";
  }

  // Al salir del for, la variable `htmlAux` debería contener algo como:
  // htmlAux = "<li>BMW</li><li>Peugeot</li><li>Chevrolet</li>..."

  $("ul").html(htmlAux); // Se insertan en el <ul> los <li>.
}

// Ejercicio 3 - Parte 4
// Versión usando FOREACH y función `append` de jQuery.

function mostrarMarcas_v2() {
  $("ul").empty(); // Se elimina contenido del <ul>. Equivalente a $("ul").html("");

  marcas.forEach(function (item) {
    $("ul").append("<li>" + item + "</li>"); // Se agrega <li> al final del <ul>.
  });
}

// Botón "Mostrar Marcas":

$("#btn-show").on("click", function () {
  $(".alert").alert("close");
  if (marcas.length !== 0) {
    mostrarMarcas_v2();
  } else {
    mostrarError("No hay marcas para mostrar.");
  }
}); // End - Click en #btn-show

/******************************************************************/

// Ejercicio 3 - Parte 5

$("#btn-remove").on("click", function () {
  if (marcas.length !== 0) {
    marcas.pop();
    mostrarMarcas_v1();
    mostrarOK("Se eliminó la última marca con éxito");
  } else {
    mostrarError("No hay marcas para eliminar.");
  }
}); // End - Click en #btn-remove

/******************************************************************/

/**
 * Ejercicio 3 - Partes 6 y 7
 *
 * Notar que no fue necesario crear una función `agregarMarca`,
 * alcanzó con crear una función anónima.
 *
 * Para saber si un elemento está en el array se usó la función `indexOf`
 * de JavaScript. También se podría haber usado la función `estaElemento`
 * creada anteriormente.
 *
 */

$("#btn-add").on("click", function () {
  var marcaIngresada = $("#marca").val();

  if (marcaIngresada === "") {
    mostrarError("Es necesario escribir la marca que se quiere agregar.");
  } else if (marcas.indexOf(marcaIngresada) !== -1) {
    mostrarError(
      "La marca <strong>" + marcaIngresada + "</strong> ya está en la lista."
    );
  } else {
    marcas.push(marcaIngresada);
    mostrarMarcas_v1();
    mostrarOK(
      "La marca <strong>" + marcaIngresada + "</strong> se agregó con éxito."
    );
  }
}); // End - Click en #btn-add

/******************************************************************/

// Ejercicio 3 - Parte 8

$("#btn-marcaremove").on("click", function () {
  var marcaARemover = $("#marcaremove").val();
  var posicion = marcas.indexOf(marcaARemover);

  if (marcaARemover === "") {
    mostrarError("Es necesario escribir la marca que se quiere remover.");
  } else if (posicion === -1) {
    mostrarError(
      "La marca <strong>" + marcaARemover + "</strong> no está en la lista."
    );
  } else {
    marcas.splice(posicion, 1);
    mostrarMarcas_v1();
    mostrarOK(
      "La marca <strong>" + marcaARemover + "</strong> se eliminó con éxito."
    );
  }
}); // End - Click en #btn-add

/******************************************************************/

// FUNCIONES AUXILIARES:

// Mostrar mensaje de error:

function mostrarError(texto) {
  // Por las dudas, cerrar alert previo:
  $(".alert").alert("close");

  var htmlAlert = `
    <div class="alert alert-danger alert-dismissible fade show" role="alert">
      <strong>Error</strong>: ${texto}
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  `;

  // Mostrar alert luego del #content:
  $("#content").after(htmlAlert);
}

// Mostrar mensaje de éxito:

function mostrarOK(texto) {
  // Por las dudas, cerrar alert previo:
  $(".alert").alert("close");

  var htmlAlert = `
    <div class="alert alert-success alert-dismissible fade show" role="alert">
      ${texto}
      <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
    </div>
  `;

  // Mostrar alert luego del #content:
  $("#content").after(htmlAlert);
}
