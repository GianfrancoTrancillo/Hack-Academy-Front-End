// Crear un array vacío:
var marcas = [];

// Insertar marcas:
marcas.push("VW");
marcas.push("Audi");
marcas.push("Volvo");
marcas.push("Fiat");

// Quitar "VW" de la lista:
// Usamos `shift` para remover el primer elemento.
marcas.shift();

// Quitar "Volvo" de la lista:
// Usamos `splice` para remover un elemento del medio.
marcas.splice(1, 1);

// Insertar "Kia" en la primera posición de la lista:
marcas.unshift("Kia");

// Mostrar el array en la consola:
console.log(marcas);

// Verificar que el array mostrado sea:
// ["Kia", "Audi", "Fiat"]
