$("#show-marcas").click(function(){

    var lasMarcas = new Vue({
        el:"#marca",
        data: {
            marcas: [{nombre:"BMW"},
            {nombre:"Audi"},
            {nombre:"Volvo"},
            {nombre:"Mercedes"},
            {nombre:"Fiat"}]   
        }
    })
}
)
$("#eliminate-marca").click(function(){
    if (marcas.length !== 0) {
        marcas.pop();
        mostrarMarcas_v1();
        mostrarOK("Se eliminó la última marca con éxito");
      } else {
        mostrarError("No hay marcas para eliminar.");
      }
    })
