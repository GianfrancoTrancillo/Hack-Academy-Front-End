function mostrarArray(arrayCualquiera) {
  arrayCualquiera.forEach((element) => {
    console.log(element);
  });
}
var marcas = ["BMW", "Peugeot", "Chevrolet", "Subaru", "Nissan"];
function estaElemento(marcas, elemento) {
  for (var i = 0; i < marcas.length; i++) {
    if (marcas[i] == elemento) {
      return true;
    }
  }
  return false;
}
